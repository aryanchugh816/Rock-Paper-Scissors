MODEL_DIR = 'cnn_tf_model'
TRAINING_DATA_DIR = 'training_data'
